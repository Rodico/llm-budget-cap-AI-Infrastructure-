"""
async_core.py — async variant of enforce_budget for `async def` LLM calls
(e.g. AsyncOpenAI, AsyncAnthropic clients).
"""

from __future__ import annotations

import functools
from typing import Callable, List, Optional, Any

from .core import (
    BudgetManager,
    BudgetExceededError,
    _extract_usage,
    estimate_cost,
)


def enforce_budget_async(
    manager: BudgetManager,
    caps: List[str],
    model: Optional[str] = None,
    estimate_input_tokens: Optional[Callable[..., int]] = None,
    estimate_output_tokens: int = 0,
    on_exceeded: Optional[Callable[[BudgetExceededError], Any]] = None,
    usage_extractor: Optional[Callable[[Any], Any]] = None,
):
    """Async counterpart of `enforce_budget`. See core.enforce_budget for
    full parameter documentation — semantics are identical, just `await`ed."""

    def decorator(fn: Callable):
        @functools.wraps(fn)
        async def wrapper(*args, **kwargs):
            call_kwargs = dict(kwargs)
            try:
                inspect_args = fn.__code__.co_varnames[: fn.__code__.co_argcount]
                call_kwargs.update(dict(zip(inspect_args, args)))
            except Exception:
                pass

            projected_cost = 0.0
            projected_tokens = 0
            if estimate_input_tokens is not None:
                try:
                    in_tok = estimate_input_tokens(*args, **kwargs)
                    projected_tokens = in_tok + estimate_output_tokens
                    projected_cost = estimate_cost(
                        model or "_default", in_tok, estimate_output_tokens, manager.price_table
                    )
                except Exception:
                    pass

            try:
                manager.check(caps, call_kwargs, projected_cost, projected_tokens)
            except BudgetExceededError as e:
                if on_exceeded is not None:
                    fallback = on_exceeded(e)
                    if fallback is not None:
                        return fallback
                raise

            result = await fn(*args, **kwargs)

            if usage_extractor is not None:
                usage = usage_extractor(result)
            else:
                usage = _extract_usage(result, model, manager.price_table)

            manager.record(caps, call_kwargs, usage)
            return result

        return wrapper

    return decorator
