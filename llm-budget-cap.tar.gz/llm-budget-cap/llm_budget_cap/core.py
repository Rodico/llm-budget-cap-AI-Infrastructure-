"""
core.py — budget caps, manager, decorator.
"""

from __future__ import annotations

import functools
import threading
import time
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Tuple, Any

from .pricing import estimate_cost, PRICE_TABLE


class BudgetExceededError(Exception):
    """Raised when a call would breach one or more BudgetCaps."""

    def __init__(self, cap_name: str, current: float, limit: float, kind: str):
        self.cap_name = cap_name
        self.current = current
        self.limit = limit
        self.kind = kind  # "cost" or "tokens"
        super().__init__(
            f"Budget cap '{cap_name}' exceeded: {kind} {current:.6f} "
            f"would exceed limit {limit:.6f}"
        )


@dataclass
class Usage:
    """Normalized usage record for a single LLM call."""
    input_tokens: int = 0
    output_tokens: int = 0
    cost_usd: float = 0.0
    model: Optional[str] = None
    timestamp: float = field(default_factory=time.time)

    @property
    def total_tokens(self) -> int:
        return self.input_tokens + self.output_tokens


@dataclass
class BudgetCap:
    """
    A single named limit.

    - max_cost_usd: hard ceiling on cumulative spend (USD) within the window.
    - max_tokens: hard ceiling on cumulative tokens within the window.
    - window_seconds: if None, the cap is cumulative for the lifetime of the
      BudgetManager (e.g. a "total project spend" cap). If set, only usage
      within the last `window_seconds` counts (sliding window) — e.g. 86400
      for a rolling daily cap.
    - key_fn: optional function (kwargs of decorated call) -> str, used to
      scope this cap per-key (e.g. per user_id, per tenant). If None, the
      cap is global across all calls.
    """
    name: str
    max_cost_usd: Optional[float] = None
    max_tokens: Optional[int] = None
    window_seconds: Optional[float] = None
    key_fn: Optional[Callable[..., str]] = None

    def __post_init__(self):
        if self.max_cost_usd is None and self.max_tokens is None:
            raise ValueError(
                f"BudgetCap '{self.name}' must set max_cost_usd and/or max_tokens"
            )


class _CapState:
    """Per-(cap, key) rolling usage log."""

    __slots__ = ("records",)

    def __init__(self):
        self.records: List[Usage] = []

    def prune(self, window_seconds: Optional[float]):
        if window_seconds is None:
            return
        cutoff = time.time() - window_seconds
        self.records = [r for r in self.records if r.timestamp >= cutoff]

    def totals(self, window_seconds: Optional[float]) -> Tuple[float, int]:
        self.prune(window_seconds)
        cost = sum(r.cost_usd for r in self.records)
        tokens = sum(r.total_tokens for r in self.records)
        return cost, tokens

    def add(self, usage: Usage):
        self.records.append(usage)


class BudgetManager:
    """
    Tracks one or more BudgetCaps and their cumulative usage.

    Thread-safe in-memory implementation. For multi-process / distributed
    deployments, swap `_state` for a Redis-backed store (see README for
    the extension point) — the interface (`check`, `record`) stays the same.
    """

    def __init__(self, price_table: Optional[Dict[str, Tuple[float, float]]] = None):
        self.price_table = price_table or PRICE_TABLE
        self._caps: Dict[str, BudgetCap] = {}
        self._state: Dict[Tuple[str, str], _CapState] = {}
        self._lock = threading.Lock()

    def add_cap(self, cap: BudgetCap) -> "BudgetManager":
        self._caps[cap.name] = cap
        return self

    def get_cap(self, name: str) -> BudgetCap:
        return self._caps[name]

    # -- internal helpers ---------------------------------------------

    def _cap_key(self, cap: BudgetCap, call_kwargs: dict) -> str:
        if cap.key_fn is None:
            return "_global"
        return str(cap.key_fn(**call_kwargs))

    def _get_state(self, cap_name: str, key: str) -> _CapState:
        sk = (cap_name, key)
        if sk not in self._state:
            self._state[sk] = _CapState()
        return self._state[sk]

    # -- public API -----------------------------------------------------

    def check(
        self,
        cap_names: List[str],
        call_kwargs: dict,
        projected_cost_usd: float = 0.0,
        projected_tokens: int = 0,
    ) -> None:
        """
        Raise BudgetExceededError if adding `projected_cost_usd` /
        `projected_tokens` to any of the named caps' current totals would
        breach that cap's limit. Read-only — does not record anything.
        """
        with self._lock:
            for name in cap_names:
                cap = self._caps[name]
                key = self._cap_key(cap, call_kwargs)
                state = self._get_state(name, key)
                cost, tokens = state.totals(cap.window_seconds)

                if cap.max_cost_usd is not None:
                    projected = cost + projected_cost_usd
                    if projected > cap.max_cost_usd:
                        raise BudgetExceededError(name, projected, cap.max_cost_usd, "cost")

                if cap.max_tokens is not None:
                    projected_tok = tokens + projected_tokens
                    if projected_tok > cap.max_tokens:
                        raise BudgetExceededError(name, projected_tok, cap.max_tokens, "tokens")

    def record(self, cap_names: List[str], call_kwargs: dict, usage: Usage) -> None:
        """Record actual usage against the named caps (post-call)."""
        with self._lock:
            for name in cap_names:
                cap = self._caps[name]
                key = self._cap_key(cap, call_kwargs)
                state = self._get_state(name, key)
                state.add(usage)

    def status(self, cap_name: str, call_kwargs: Optional[dict] = None) -> dict:
        """Return current usage vs. limit for a cap (optionally scoped by key)."""
        cap = self._caps[cap_name]
        key = self._cap_key(cap, call_kwargs or {})
        state = self._get_state(cap_name, key)
        cost, tokens = state.totals(cap.window_seconds)
        return {
            "cap": cap_name,
            "key": key,
            "cost_usd": cost,
            "max_cost_usd": cap.max_cost_usd,
            "tokens": tokens,
            "max_tokens": cap.max_tokens,
            "window_seconds": cap.window_seconds,
        }


# ---------------------------------------------------------------------
# Usage extraction helpers — best-effort parsing of common SDK responses
# ---------------------------------------------------------------------

def _extract_usage(result: Any, model: Optional[str], price_table) -> Usage:
    """
    Best-effort extraction of token usage from common LLM SDK return objects
    (OpenAI, Anthropic). Falls back to zero usage if shape is unrecognized —
    in that case, post-call enforcement degrades to "no-op" but the pre-call
    `max_calls_estimate` / `projected_cost_usd` argument still protects you.
    """
    input_tokens = output_tokens = 0
    detected_model = model

    usage_obj = getattr(result, "usage", None)
    if usage_obj is None and isinstance(result, dict):
        usage_obj = result.get("usage")

    if usage_obj is not None:
        # OpenAI: prompt_tokens / completion_tokens
        # Anthropic: input_tokens / output_tokens
        input_tokens = (
            getattr(usage_obj, "input_tokens", None)
            or getattr(usage_obj, "prompt_tokens", None)
            or (usage_obj.get("input_tokens") if isinstance(usage_obj, dict) else None)
            or (usage_obj.get("prompt_tokens") if isinstance(usage_obj, dict) else None)
            or 0
        )
        output_tokens = (
            getattr(usage_obj, "output_tokens", None)
            or getattr(usage_obj, "completion_tokens", None)
            or (usage_obj.get("output_tokens") if isinstance(usage_obj, dict) else None)
            or (usage_obj.get("completion_tokens") if isinstance(usage_obj, dict) else None)
            or 0
        )

    if detected_model is None:
        detected_model = getattr(result, "model", None) or (
            result.get("model") if isinstance(result, dict) else None
        )

    cost = estimate_cost(detected_model or "_default", input_tokens, output_tokens, price_table)
    return Usage(input_tokens=input_tokens, output_tokens=output_tokens,
                  cost_usd=cost, model=detected_model)


# ---------------------------------------------------------------------
# Decorator
# ---------------------------------------------------------------------

def enforce_budget(
    manager: BudgetManager,
    caps: List[str],
    model: Optional[str] = None,
    estimate_input_tokens: Optional[Callable[..., int]] = None,
    estimate_output_tokens: int = 0,
    on_exceeded: Optional[Callable[[BudgetExceededError], Any]] = None,
    usage_extractor: Optional[Callable[[Any], Usage]] = None,
):
    """
    Decorator enforcing one or more BudgetCaps around an LLM-calling function.

    Parameters
    ----------
    manager: the BudgetManager holding the cap definitions.
    caps: list of cap names (from manager.add_cap) to enforce for this function.
    model: model name used for pricing. If None, inferred post-call from the
        response object (OpenAI/Anthropic-shaped) when possible.
    estimate_input_tokens: optional callable, given the same args/kwargs as the
        wrapped function, returning an estimated input token count. Used for
        the PRE-call check so you can reject before spending anything (e.g.
        a crude `len(prompt)//4`). If omitted, pre-call check only enforces
        based on *already recorded* usage (i.e. it stops further calls once
        a cap is already breached, but won't predict this call's cost).
    estimate_output_tokens: a fixed estimate of output tokens for the pre-call
        check (e.g. your `max_tokens` request parameter). Defaults to 0.
    on_exceeded: optional callable invoked with the BudgetExceededError instead
        of raising it. If it returns a value, that value is returned from the
        wrapped function call (e.g. a cached/fallback response). If it returns
        None (or raises), the original BudgetExceededError propagates.
    usage_extractor: optional callable(result) -> Usage for custom SDKs whose
        response shape isn't covered by the built-in OpenAI/Anthropic parser.

    Behavior
    --------
    1. Pre-call: estimates projected cost/tokens and calls manager.check().
       Raises BudgetExceededError (or routes to on_exceeded) if any cap
       would be breached — the wrapped function is NOT called.
    2. Calls the wrapped function.
    3. Post-call: extracts actual usage from the result and records it
       against all listed caps via manager.record().
    """

    def decorator(fn: Callable):
        @functools.wraps(fn)
        def wrapper(*args, **kwargs):
            call_kwargs = dict(kwargs)
            try:
                inspect_args = fn.__code__.co_varnames[: fn.__code__.co_argcount]
                call_kwargs.update(dict(zip(inspect_args, args)))
            except Exception:
                pass

            projected_cost = 0.0
            projected_tokens = 0
            if estimate_input_tokens is not None:
                try:
                    in_tok = estimate_input_tokens(*args, **kwargs)
                    projected_tokens = in_tok + estimate_output_tokens
                    projected_cost = estimate_cost(
                        model or "_default", in_tok, estimate_output_tokens, manager.price_table
                    )
                except Exception:
                    pass

            try:
                manager.check(caps, call_kwargs, projected_cost, projected_tokens)
            except BudgetExceededError as e:
                if on_exceeded is not None:
                    fallback = on_exceeded(e)
                    if fallback is not None:
                        return fallback
                raise

            result = fn(*args, **kwargs)

            if usage_extractor is not None:
                usage = usage_extractor(result)
            else:
                usage = _extract_usage(result, model, manager.price_table)

            manager.record(caps, call_kwargs, usage)
            return result

        return wrapper

    return decorator
