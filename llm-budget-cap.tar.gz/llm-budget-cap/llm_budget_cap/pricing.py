"""
pricing.py — lightweight, overridable price table.

Prices are USD per 1,000 tokens. These are illustrative defaults and WILL
drift out of date — pass your own `price_table` to BudgetManager/enforce_budget
for accuracy, or override entries here.
"""

from typing import Dict, Tuple, Optional

# model_name -> (input_price_per_1k, output_price_per_1k)
PRICE_TABLE: Dict[str, Tuple[float, float]] = {
    # OpenAI
    "gpt-4o": (0.0025, 0.01),
    "gpt-4o-mini": (0.00015, 0.0006),
    "gpt-4-turbo": (0.01, 0.03),
    "gpt-3.5-turbo": (0.0005, 0.0015),
    "o1": (0.015, 0.06),
    "o1-mini": (0.003, 0.012),
    # Anthropic
    "claude-opus-4-6": (0.015, 0.075),
    "claude-sonnet-4-6": (0.003, 0.015),
    "claude-haiku-4-5": (0.0008, 0.004),
    # Generic fallback if model unknown
    "_default": (0.001, 0.002),
}


def estimate_cost(
    model: str,
    input_tokens: int = 0,
    output_tokens: int = 0,
    price_table: Optional[Dict[str, Tuple[float, float]]] = None,
) -> float:
    """Return estimated USD cost for given token counts and model."""
    table = price_table or PRICE_TABLE
    in_price, out_price = table.get(model, table.get("_default", (0.001, 0.002)))
    return (input_tokens / 1000.0) * in_price + (output_tokens / 1000.0) * out_price
