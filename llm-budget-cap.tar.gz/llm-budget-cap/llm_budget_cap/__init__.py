"""
llm-budget-cap
==============

Inline, in-process budget enforcement for LLM calls. Stops runaway spend
*before* it happens, rather than after a billing alert fires.

Core concepts
-------------
- BudgetCap: a named limit (e.g. "per_request", "per_user_daily", "global_monthly")
  with a max cost (USD) and/or max tokens, over a sliding/fixed window.
- BudgetManager: tracks spend across one or more BudgetCaps, in-memory
  (pluggable storage backends can be added for distributed use).
- @enforce_budget: decorator that wraps an LLM-calling function. Before the
  call, it checks all relevant caps would not be exceeded. After the call,
  it records actual usage (tokens/cost) returned by the wrapped function.
- BudgetExceededError: raised (or callback-handled) when a cap would be breached.

Pricing
-------
A small built-in price table for common models (USD per 1K tokens, input/output
separately) is provided in `pricing.py`, but you can pass your own.

Quick start
-----------
    from llm_budget_cap import BudgetManager, BudgetCap, enforce_budget

    budgets = BudgetManager()
    budgets.add_cap(BudgetCap(name="per_call", max_cost_usd=0.05))
    budgets.add_cap(BudgetCap(name="daily_global", max_cost_usd=20.0, window_seconds=86400))

    @enforce_budget(budgets, caps=["per_call", "daily_global"], model="gpt-4o")
    def ask(prompt):
        resp = client.chat.completions.create(...)
        # return value's usage is auto-extracted for OpenAI-style responses
        return resp

    ask("hello")  # raises BudgetExceededError if it would blow a cap
"""

from .core import (
    BudgetCap,
    BudgetManager,
    BudgetExceededError,
    enforce_budget,
    Usage,
)
from .pricing import estimate_cost, PRICE_TABLE
from .async_core import enforce_budget_async

__all__ = [
    "enforce_budget_async",
    "BudgetCap",
    "BudgetManager",
    "BudgetExceededError",
    "enforce_budget",
    "Usage",
    "estimate_cost",
    "PRICE_TABLE",
]

__version__ = "0.1.0"
