"""
Example: wrapping an OpenAI-style chat call with multi-tier budget caps.

Run: python examples/openai_example.py
(No real API key needed — this uses a fake client for demonstration.)
"""

from llm_budget_cap import BudgetManager, BudgetCap, enforce_budget, BudgetExceededError


# --- Fake client standing in for `openai.OpenAI()` -------------------------
class FakeUsage:
    def __init__(self, prompt_tokens, completion_tokens):
        self.prompt_tokens = prompt_tokens
        self.completion_tokens = completion_tokens


class FakeResponse:
    def __init__(self, prompt_tokens, completion_tokens, model):
        self.usage = FakeUsage(prompt_tokens, completion_tokens)
        self.model = model
        self.choices = [type("C", (), {"message": type("M", (), {"content": "...response..."})()})]


def fake_openai_call(prompt, model="gpt-4o-mini"):
    # Pretend ~4 chars/token for the prompt, fixed-size completion.
    return FakeResponse(prompt_tokens=len(prompt) // 4, completion_tokens=120, model=model)


# --- Set up budgets ----------------------------------------------------------
budgets = BudgetManager()

# Tier 1: never let a single call cost more than 2 cents.
budgets.add_cap(BudgetCap(name="per_call", max_cost_usd=0.02))

# Tier 2: each user gets at most $0.50/day (rolling 24h window), scoped by user_id.
budgets.add_cap(BudgetCap(
    name="per_user_daily",
    max_cost_usd=0.50,
    window_seconds=86400,
    key_fn=lambda user_id, **_: user_id,
))

# Tier 3: global hard ceiling for the whole app, lifetime of this process.
budgets.add_cap(BudgetCap(name="global_total", max_cost_usd=5.00))


@enforce_budget(
    budgets,
    caps=["per_call", "per_user_daily", "global_total"],
    model="gpt-4o-mini",
    # Pre-call estimate: ~4 chars/token, request up to 120 output tokens.
    estimate_input_tokens=lambda user_id, prompt, model="gpt-4o-mini": len(prompt) // 4,
    estimate_output_tokens=120,
    on_exceeded=lambda e: print(f"  [BLOCKED] {e}") or "Sorry, budget exceeded — try again later.",
)
def ask(user_id, prompt, model="gpt-4o-mini"):
    return fake_openai_call(prompt, model=model)


if __name__ == "__main__":
    print(ask("alice", "What's the weather like in general terms?"))
    print(ask("alice", "Tell me a short joke."))

    print("\nStatus for alice:", budgets.status("per_user_daily", {"user_id": "alice"}))
    print("Global status:", budgets.status("global_total"))

    # Simulate a runaway loop — global cap will eventually kick in.
    print("\nSimulating a runaway loop against the global cap...")
    for i in range(2000):
        result = ask("bob", "x" * 4000)  # large prompt
        if "budget exceeded" in str(result):
            print(f"Stopped after {i} calls.")
            break
