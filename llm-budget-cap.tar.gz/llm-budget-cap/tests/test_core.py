import time
import pytest

from llm_budget_cap import BudgetManager, BudgetCap, BudgetExceededError, enforce_budget, Usage


def make_fake_response(input_tokens, output_tokens, model="gpt-4o-mini"):
    class FakeUsage:
        def __init__(self):
            self.prompt_tokens = input_tokens
            self.completion_tokens = output_tokens

    class FakeResponse:
        def __init__(self):
            self.usage = FakeUsage()
            self.model = model

    return FakeResponse()


def test_per_call_cost_cap_blocks_expensive_call():
    budgets = BudgetManager()
    budgets.add_cap(BudgetCap(name="per_call", max_cost_usd=0.01))

    @enforce_budget(budgets, caps=["per_call"], model="gpt-4o")
    def call(prompt):
        return make_fake_response(input_tokens=1000, output_tokens=1000, model="gpt-4o")

    # First call executes (pre-check has nothing to compare against yet),
    # but its actual cost (0.0125) exceeds the 0.01 cap once recorded.
    call("hi")
    # Second call's pre-check sees current cost already > limit -> blocked.
    with pytest.raises(BudgetExceededError):
        call("hi again")


def test_cumulative_cap_accumulates_and_blocks():
    budgets = BudgetManager()
    budgets.add_cap(BudgetCap(name="total", max_cost_usd=0.02))

    @enforce_budget(budgets, caps=["total"], model="gpt-4o-mini")
    def call(prompt):
        return make_fake_response(input_tokens=1000, output_tokens=1000, model="gpt-4o-mini")

    # gpt-4o-mini: 1000@0.00015 + 1000@0.0006 = 0.00075 per call
    call("a")
    call("b")
    call("c")  # 3 * 0.00075 = 0.00225, still under 0.02
    status = budgets.status("total")
    assert status["cost_usd"] == pytest.approx(0.00225)

    # Drive it over the cap; expect a BudgetExceededError at some point
    with pytest.raises(BudgetExceededError):
        for _ in range(40):
            call("x")


def test_per_key_scoping_isolates_users():
    budgets = BudgetManager()
    budgets.add_cap(
        BudgetCap(
            name="per_user",
            max_cost_usd=0.001,
            key_fn=lambda user_id, **_: user_id,
        )
    )

    @enforce_budget(budgets, caps=["per_user"], model="gpt-4o-mini")
    def call(user_id, prompt):
        return make_fake_response(input_tokens=100, output_tokens=100, model="gpt-4o-mini")

    # cost per call ~ 0.000075, under 0.001
    call("alice", "hi")
    call("alice", "hi")
    call("alice", "hi")  # alice now near/over limit depending on rounding

    # bob is independent — should not be blocked by alice's usage
    call("bob", "hi")


def test_sliding_window_expires_old_usage():
    budgets = BudgetManager()
    budgets.add_cap(BudgetCap(name="windowed", max_cost_usd=0.00003, window_seconds=0.2))

    @enforce_budget(budgets, caps=["windowed"], model="gpt-4o-mini")
    def call(prompt):
        return make_fake_response(input_tokens=50, output_tokens=50, model="gpt-4o-mini")

    call("a")
    # second call's pre-check sees current cost > limit -> blocked
    with pytest.raises(BudgetExceededError):
        call("b")

    time.sleep(0.25)
    # window expired — should succeed again
    call("c")


def test_on_exceeded_callback_returns_fallback():
    budgets = BudgetManager()
    budgets.add_cap(BudgetCap(name="per_call", max_cost_usd=0.0))

    def fallback(err):
        return "FALLBACK_RESPONSE"

    @enforce_budget(budgets, caps=["per_call"], model="gpt-4o", on_exceeded=fallback)
    def call(prompt):
        return make_fake_response(input_tokens=10, output_tokens=10, model="gpt-4o")

    call("hi")  # passes pre-check (0<=0), records cost > 0
    result = call("hi again")  # pre-check now fails -> fallback
    assert result == "FALLBACK_RESPONSE"


def test_pre_call_estimate_blocks_before_calling_fn():
    budgets = BudgetManager()
    budgets.add_cap(BudgetCap(name="per_call", max_cost_usd=0.001))

    called = {"n": 0}

    @enforce_budget(
        budgets,
        caps=["per_call"],
        model="gpt-4o",
        estimate_input_tokens=lambda prompt: len(prompt) * 10,  # deliberately huge
        estimate_output_tokens=1000,
    )
    def call(prompt):
        called["n"] += 1
        return make_fake_response(input_tokens=10, output_tokens=10, model="gpt-4o")

    with pytest.raises(BudgetExceededError):
        call("this is a long prompt")

    # function body should never have executed
    assert called["n"] == 0


def test_token_cap():
    budgets = BudgetManager()
    budgets.add_cap(BudgetCap(name="token_cap", max_tokens=150))

    @enforce_budget(
        budgets,
        caps=["token_cap"],
        estimate_input_tokens=lambda prompt: 100,
        estimate_output_tokens=40,
    )
    def call(prompt):
        return make_fake_response(input_tokens=100, output_tokens=40)

    call("a")  # records 140 tokens, ok (0 + 140 <= 150)
    with pytest.raises(BudgetExceededError):
        call("b")  # pre-check: 140 + 140 = 280 > 150

